<template>
    <div>
       
   <b-navbar>
        <template slot="brand">
            <b-navbar-item>
                <p>BuscaSong</p>
            </b-navbar-item>
            <b-navbar-item tag="router-link" :to="{ path: '/' }">
              <img
                    src="https://upload-icon.s3.us-east-2.amazonaws.com/uploads/icons/png/5880947611530507351-512.png"
                    alt="Icono"
                >
            </b-navbar-item>
        </template>
        <template slot="start">
            <b-navbar-item>
              <router-link :to="{name:'Login'}">Login</router-link>
            </b-navbar-item>
            <b-navbar-item >
                <router-link :to="{name:'Favoritos'}">Canciones Favoritas</router-link>
            </b-navbar-item>
            <b-navbar-item> 
                <router-link :to="{name:'Editar'}">Editar</router-link>
            </b-navbar-item>
              <b-navbar-item> 
                <router-link :to="{name:'Home'}">Home</router-link>
            </b-navbar-item>
        </template>
         <template slot="end">
            <b-navbar-item tag="div">
                <div class="buttons">
                    <a class="button is-primary" @click="logout">
                        <strong>Log Out</strong>
                    </a>

                </div>
            </b-navbar-item>
        </template>
        </b-navbar>
<router-view></router-view>
    </div>
</template>

<script>
import Firebase from 'firebase'
export default {
     methods: {
    logout() {
      Firebase.auth()
        .signOut()
        .then(() => {
          alert("Te haz deslogeado")
          this.$router.push({ name: "Login" })
        });
    },
  },
}
</script>
<style lang="scss">
$color-fondo: "#ecf4f3";
$color-navbar: "#76dbd1";
$color-fondo-cards: "#d1eecc";
$color-botones-iconos: '#57a99a';
$letras-titulos: 'MuseoModerno', cursive;
$letras-textos: 'Roboto Condensed', sans-serif;



    
</style>
