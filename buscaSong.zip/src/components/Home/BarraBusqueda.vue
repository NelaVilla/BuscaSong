<template>
  <div id="barrabusqueda">
    <section class="container">
      <b-field>
        <div class="columns columns is-mobile is-multiline is-centered">
          <div class="column is-half">
            <b-input
              placeholder="Escribe el nombre de la canción"
              v-model="title"
            ></b-input>
          </div>

          <div class="column is-half">
            <b-input
              placeholder="Escribe el nombre del artista o grupo musical"
              v-model="artist"
            ></b-input>
          </div>
        </div>
      </b-field>

      <template>
        <section class="columns is-mobile is-multiline is-centered">
          <b-button @click="buscar()">obten tu canción</b-button>
          <b-button @click="infoArtista()">obten al artista</b-button>
        </section>
      </template>
    </section>
    <!--Card con letra--->

    <div class="columns is-centered is-mobile">
      <div class="column is-mobile is-multiline is-centered">
        <div class="column">
          <div class="card container">
            <header class="card-header">
              <p class="card-header-title">
                cancion
              </p>
            </header>

            <div class="card-content">
              <div class="content">
                {{ letraCancion }}
              </div>
            </div>
            <footer class="card-footer">
              <span class="footer-icon-item">
                <img
                  src="https://upload-icon.s3.us-east-2.amazonaws.com/uploads/icons/png/12489151821579105126-512.png"
                  alt=""
                  width="50px"
                  height="50px"
                />
              </span>
            </footer>
          </div>
        </div>
      </div>

      <div class="column is-mobile is-multiline is-centered">
        <div class="column">
          <div class="card">
            <div class="card-image">
              <figure class="image is-4by3">
                <img
                  src=""
                  alt="Placeholder image"
                />
              </figure>
            </div>
            <header class="card-header">
              <p class="card-header-title">
                Datos del artista
              </p>
            </header>
            <div class="card-content">
              <div class="content">
                <h1>{{ nombreArtista }}</h1>
                <p>
                  {{ bioArtista }}
                </p>
              </div>
            </div>
            <footer class="card-footer">
              <figure class="card-footer-item">
                <img
                  src="https://upload-icon.s3.us-east-2.amazonaws.com/uploads/icons/png/12489151821579105126-512.png"
                  alt=""
                  width="50px"
                  height="50px"
                />
              </figure>

              <a href="#" class="card-footer-item">Edit</a>
              <a href="#" class="card-footer-item">Delete</a>
            </footer>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Firebase from "firebase";

export default {
  name: "barrabusqueda",

  data() {
    return {
      artist: "",
      title: "",
      cancion: "",
      datosArtist: {
        name: "",
        image: [{
          text:""
        }],
        bio: {
          summary: "",
        },
      },
  
    };
  },

  methods: {
    buscar() {
      let artista = this.artist;
      let titulo = this.title;
      return axios
        .get(`https://api.lyrics.ovh/v1/${artista}/${titulo}`, {
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
        })
        .then((result) => {
          this.cancion = result.data.lyrics;
        })
        .catch((error) => {
          console.log("no existe esa cancion");
        });
    },

    infoArtista() {
      let artista = this.artist;
      let keyFm = "2fb853fec0984769558ca651f33fe319";
      return axios
        .get(
          `http://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=${artista}&api_key=${keyFm}&format=json`,
          {
            headers: {
              "Content-Type": "application/json; charset=utf-8",
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((result) => {
          console.log(result.data);
          this.datosArtist = result.data.artist;
        });
    },
  },
  computed: {
    letraCancion() {
      let cancionL = this.cancion;
      return cancionL;
    },
    nombreArtista() {
      let artistName = this.datosArtist.name;
      return artistName;
    },
    bioArtista() {
      let artistBio = this.datosArtist.bio.summary;
      return artistBio;
    }
    
  },
};
</script>

