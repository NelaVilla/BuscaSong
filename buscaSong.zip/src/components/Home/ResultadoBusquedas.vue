<template>
    <div id="ResultadoBusquedas">
    
    <div class="columns is-centered is-mobile">
      <div class="column is-mobile is-multiline is-centered">
        <div class="column">
          <div class="card container">
            <header class="card-header">
              <p class="card-header-title">
                cancion
              </p>
            </header>

            <div class="card-content">
              <div class="content">
                {{ letraCancion }}
              </div>
            </div>
            <footer class="card-footer">
              <span class="footer-icon">
                <img
                  src="https://upload-icon.s3.us-east-2.amazonaws.com/uploads/icons/png/12489151821579105126-512.png"
                  alt=""
                  width="50px"
                  height="50px"
                />
              </span>
            </footer>
          </div>
        </div>
      </div>

      <div class="column is-mobile is-multiline is-centered">
        <div class="column">
          <div class="card">
            <div class="card-image">
              <figure class="image is-4by3">
                <img
                  src="https://promocionmusical.es/wp-content/uploads/2016/02/a-1140x765.jpg"
                  alt="Placeholder image"
                />
              </figure>
            </div>
            <header class="card-header">
              <p class="card-header-title">
                Component
              </p>
            </header>
            <div class="card-content">
              <div class="content">
                <h1>{{ nombreArtista }}</h1>
                <p>
                  {{ bioArtista }}
                </p>
              </div>
            </div>
            <footer class="card-footer">
              <figure class="card-footer-item">
                <img
                  src="https://upload-icon.s3.us-east-2.amazonaws.com/uploads/icons/png/12489151821579105126-512.png"
                  alt=""
                  width="50px"
                  height="50px"
                />
              </figure>

              <a href="#" class="card-footer-item">Edit</a>
              <a href="#" class="card-footer-item">Delete</a>
            </footer>
          </div>
        </div>
      </div>
    </div>
    </div>
</template>

<script>
export default {
  name:'ResultadosBusquedas'
}
</script>