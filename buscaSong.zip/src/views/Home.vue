<template>
  <div class="home">
    <BarraBusqueda />
  </div>
</template>

<script>
// @ is an alias to /src
import BarraBusqueda from "@/components/Home/BarraBusqueda.vue";
export default {
  name: "Home",
  components: {
    BarraBusqueda,
  },
 
};
</script>
