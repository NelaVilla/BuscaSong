<template>
    <div id="login">
        <section>
        <b-field label="Email">
            <b-input type="email" v-model="email">
            </b-input>
        </b-field>

        <b-field label="Password">
            <b-input type="password" v-model="password">
            </b-input>
        </b-field>
<b-button rounded @click="login">Login</b-button>
    </section>
    </div>
</template>

<script>
import Firebase from 'firebase'
export default {
    name:'login',
    data(){
        return{
            email:'',
            password:''
        }
    },
    methods: {
        login(){
            Firebase.auth().signInWithEmailAndPassword(this.email, this.password)
            .then(
                accept =>{
                    alert('Fuiste Loggeado')
                    console.log(Firebase.auth().currentUser.email)
                    this.$router.push({ name: 'Home' });

                },
                reject =>{
                    alert('No te haz loggeado')
                    console.log(reject.message)

                }
            )
        }
    },
}
</script>