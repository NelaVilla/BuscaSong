<template>
    <div>
        <Tabla></Tabla>
    </div>
</template>
<script>
// @ is an alias to /src
import Tabla from "@/components/Favoritos/Tabla.vue";

export default {
  name: "app",
  components: {
    Tabla
  }
};
</script>